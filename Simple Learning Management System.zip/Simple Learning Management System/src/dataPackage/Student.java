package dataPackage;

public class Student
{
    private int     id;
    private String  name;
    private int     grade;
    private String  email;
    private String  address;
    private String  region;
    private String  country;


}
