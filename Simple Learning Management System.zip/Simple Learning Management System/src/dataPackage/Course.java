package dataPackage;

public class Course
{
    private int     id;
    private String  name;
    private String  instructor;
    private String  courseDuration;
    private String  courseTime;
    private String  location;


}
